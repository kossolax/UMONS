#pragma once

#include <stdlib.h>
#include <stdint.h>

void RD_init();
uint64_t RD_next(void);
